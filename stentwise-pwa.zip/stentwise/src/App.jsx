import { useState, useRef, useCallback } from "react";

const MODEL = "claude-sonnet-4-20250514";

const MODULES = [
  // ── 1. AUC / PCI vs Medical Therapy ────────────────────────────────────────
  {
    id: "auc",
    label: "PCI vs Med Therapy",
    icon: "⚖️",
    accent: "var(--orange)",
    accentHex: "#d4823a",
    prompt: `You are a board-certified interventional cardiologist. Provide a comprehensive, structured, HIPAA-safe clinical reference on Appropriate Use Criteria (AUC) and Indications for PCI vs Medical Therapy vs CABG, incorporating:
- 2021 ACC/AHA/SCAI Guideline for Coronary Artery Revascularization
- 2025 ACC/AHA/ACEP/NAEMSP/SCAI ACS Guideline
- ISCHEMIA, FAME 2, SYNTAX, EXCEL, NOBLE, FREEDOM trial evidence

## Core Principle: Heart Team Approach
- Class I recommendation: multidisciplinary Heart Team for complex CAD where optimal strategy is unclear
- Patient-centered care: incorporate preferences, shared decision-making, quality of life goals
- Equity of care: treatment decisions should be made irrespective of sex, race, or ethnicity

## AUC Framework — When PCI Is Appropriate
Reference the ACC/AHA/SCAI AUC for coronary revascularization. Categories:
- **Appropriate (A)**: expected benefit substantially exceeds expected risk/harm
- **May Be Appropriate (M)**: expected benefit may or may not exceed risk; reasonable depending on patient characteristics
- **Rarely Appropriate (R)**: expected risk/harm exceeds benefit or evidence is insufficient

## Stable Ischemic Heart Disease (SIHD) — PCI vs Medical Therapy

### When PCI Improves SURVIVAL (Class I/IIa Indications):
- Left main stenosis ≥50%: CABG preferred (Class I); PCI reasonable if anatomically suitable AND low-medium SYNTAX score (Class IIa)
- EF ≤35% with multivessel CAD: CABG preferred (Class I); revascularization over medical therapy
- Triple-vessel disease + diabetes: CABG recommended (Class I per FREEDOM trial); PCI only if poor surgical candidate
- Proximal LAD disease: CABG reasonable (Class IIa); PCI an option

### When PCI Improves SYMPTOMS (NOT survival) in SIHD:
- ISCHEMIA trial (2019): in SIHD with moderate-to-severe ischemia (EF>35%, no unprotected left main): initial invasive strategy NOT superior to OMT for death, MI, cardiac arrest
  - Key exception: patients with CCS class III-IV angina — revascularization relieves symptoms (Class I)
  - PCI appropriate for refractory angina despite maximally tolerated OMT (Class I)
- FAME 2 trial: FFR-guided PCI reduces urgent revascularization vs medical therapy in stable CAD with hemodynamically significant stenoses

### When to Choose CABG Over PCI in Stable CAD:
- SYNTAX score >22: CABG preferred over PCI (Class I for multivessel, Class IIa for LM)
- Diabetes + multivessel CAD: CABG superior (FREEDOM trial: 5-year MACE 26.6% PCI vs 18.7% CABG)
- Complex triple-vessel CAD (SYNTAX >32): CABG strongly preferred
- LV dysfunction (EF 35–50%) + multivessel: CABG Class IIa

### Medical Therapy Preferred Over PCI (Rarely Appropriate):
- SIHD, 1-2 vessel disease (non-proximal LAD), no ischemia on stress testing, no symptoms: medical therapy preferred
- SIHD with negative or low-risk stress test: no indication for PCI (Class III)
- Non-obstructive CAD (<50% stenosis): PCI not indicated

## ACS — PCI Indications

### STEMI — PCI Indications (Class I):
- Primary PCI within 90 min of first medical contact (FMC-to-device): Class I Level A
- Transfer to PCI-capable hospital if FMC-to-device ≤120 min (Class I)
- Fibrinolysis if PCI delay >120 min from symptoms AND no contraindication (Class I)
  - Rescue PCI for failed fibrinolysis: Class I
  - Routine early angiography 2–24h after successful fibrinolysis: Class I
- Culprit-only PCI in cardiogenic shock: Class I (CULPRIT-SHOCK trial)
- Complete revascularization in hemodynamically stable STEMI + multivessel: Class I (2025 update) — index or staged

### NSTE-ACS — Invasive vs Conservative Strategy:

#### Early Invasive Strategy (<24h) — Class I:
- GRACE score >140 (high-risk)
- Elevated troponin
- New ST-segment depression ≥0.5mm
- Heart failure or hemodynamic instability
- Sustained VT/VF
- Prior CABG or PCI within 6 months
- TIMI Risk Score ≥3

#### Selective Conservative Strategy — Reasonable (Class IIa):
- Low-risk TIMI 0–2 without above high-risk features
- HEART score ≤3
- Women with low-risk features (avoid excess invasive procedures)

#### Conservative (Medical) Strategy — Class I appropriate when:
- Patient preference after full shared decision-making discussion
- Significant comorbidity where risk of procedure exceeds benefit
- No high-risk features on non-invasive testing

## Physiology-Guided PCI (FFR/iFR/Resting Pd/Pa)
- FFR ≤0.80: functionally significant; PCI beneficial (DEFER, FAME, FAME 2 trials)
- FFR 0.75–0.80: grey zone; clinical judgment + symptoms
- FFR >0.80: deferral safe; medical therapy non-inferior (5-year outcomes)
- iFR ≤0.89: equivalent to FFR (DEFINE-FLAIR, iFR SWEDE-HEART trials) — Class I guidance
- Instantaneous wave-free ratio (iFR): eliminates need for adenosine; equivalent outcomes
- Non-hyperemic pressure ratios (NHPR): Pd/Pa, RFR — acceptable alternatives
- Class I (2021 guideline): use intracoronary physiologic assessment to evaluate intermediate lesions (40–70%)

## Special Situations

### Left Main Disease:
- EXCEL trial (PCI vs CABG): similar 3-year MACE; PCI acceptable for low-intermediate SYNTAX
- NOBLE trial: CABG superior at 5 years for non-procedural MI
- 2021 guideline: left main PCI Class IIa for SYNTAX ≤32, acceptable anatomy
- Heart Team decision mandatory

### Chronic Total Occlusions (CTO):
- Symptom-driven: PCI reasonable if significant angina or ischemia in CTO territory
- Appropriate: Class M (May Be Appropriate) in most cases per AUC
- EUROCTO, REVASC-CTO, DECISION-CTO: PCI improved angina; no survival benefit
- High procedural risk: radiation, contrast, perforation risk; experienced operator required

### Multivessel PCI vs Staged:
- Complete revascularization preferred over culprit-only in stable SIHD (ISCHEMIA nuanced)
- FFR-guided complete revascularization superior to angiography-guided (FAME trial)
- Staging: complete during index hospitalization or within 45 days; both strategies acceptable

### Saphenous Vein Graft (SVG) PCI:
- Embolic protection device recommended (Class I)
- High failure/restenosis rates vs native vessel PCI
- CABG re-do vs SVG PCI: Heart Team decision

## Contraindications to PCI (Class III — Harm):
- No ischemia on non-invasive testing in stable CAD without symptoms
- Non-obstructive disease (<50%) without physiologic significance
- Poor operator/institutional volume (high-risk cases require >200 PCI/year center)
- Inability to comply with dual antiplatelet therapy without compelling reason to discontinue

## Key AUC Scoring Tables (summarize):
### Stable CAD, 1 vessel:
- No symptoms, no ischemia: Rarely Appropriate
- CCS I-II angina, medical therapy not tried: May Be Appropriate
- CCS III-IV angina on OMT: Appropriate

### Stable CAD, 2-3 vessel (non-LM):
- Moderate-severe ischemia, symptoms on OMT: Appropriate
- No symptoms, no ischemia, non-proximal LAD: Rarely Appropriate
- FFR ≤0.80, CCS II-IV angina: Appropriate

Format with ## and ### headers. Cite trial names, Class I/IIa/IIb/III, and Level of Evidence explicitly. This is critical decision-support content.`
  },

  // ── 2. PCI Risk ─────────────────────────────────────────────────────────────
  {
    id: "pci_risk",
    label: "PCI Risk",
    icon: "⚠️",
    accent: "var(--red)",
    accentHex: "#e05252",
    prompt: `You are a board-certified interventional cardiologist. Provide a concise, structured, HIPAA-safe reference on PCI Risk Assessment per the 2025 ACC/AHA ACS Guideline and 2021 ACC/AHA/SCAI Revascularization Guideline.

## Pre-Procedural Risk Scoring
- SYNTAX Score I & II: anatomic complexity, PCI vs CABG thresholds (≤22 PCI acceptable; >22 CABG preferred for multivessel)
- EuroSCORE II: surgical risk — guides Heart Team decision
- STS Score: Society of Thoracic Surgeons; Class I for CABG candidates
- NCDR CathPCI Risk Score: in-hospital mortality prediction for PCI

## High-Risk Patient Features
- Cardiogenic shock, hemodynamic instability
- EF ≤35% (revascularization benefit, higher procedural risk)
- CKD: eGFR <30 — contrast-AKI risk, bleeding risk, poorer outcomes
- Prior CABG: graft anatomy, SVG intervention considerations
- Age >80: frailty assessment, STS/EuroSCORE II essential
- Diabetes: multivessel decision (FREEDOM trial — favor CABG)

## High-Risk Lesion Features
- Unprotected left main: SYNTAX score mandatory, Heart Team
- Proximal LAD: significant ischemic territory
- Bifurcation (Medina classification): provisional vs 2-stent strategy
- Heavy calcification: rotational atherectomy (RA), orbital atherectomy (OA), IVL — IVUS/OCT to guide
- CTO: success rates 85–90% experienced operator; perforation, radiation, contrast risk
- Ostial/aorto-ostial: higher restenosis; IVUS essential

## Intracoronary Imaging — CLASS I (2025 Upgrade)
- IVUS and OCT: Class I Level A for complex lesions (2025 ACS Guideline)
- Indications: left main, ISR, calcification, bifurcation, stent sizing, optimization
- Key trials: ILUMIEN IV (OCT vs angiography), OCTOBER (bifurcation), RENOVATE-COMPLEX-PCI
- MSA (minimum stent area) targets: LM ≥8 mm², LAD ≥6 mm², non-LAD ≥5 mm² (IVUS)

## Hemodynamic Support — When to Consider
- IABP: IABP-SHOCK II — no mortality benefit in cardiogenic shock; still used selectively
- Impella CP/5.0: PROTECT III — high-risk PCI (EF<35%, multivessel, last vessel); Door-to-unloading trial
- Microaxial flow pump (Impella): Class IIa for cardiogenic shock post-MI (DanGer Shock trial — 2024; first survival benefit shown)
- VA-ECMO: ECMO-CS trial — no benefit for routine use; selected refractory shock cases
- Algorithm: EF <35% + multivessel + no shock → Impella CP prophylactic reasonable; CS → microaxial pump Class IIa

## Contrast-Associated AKI Prevention
- NCDR CathPCI risk tool: pre-procedure eGFR, DM, HF, age
- IV hydration: isotonic saline 1 mL/kg/hr 3–12h pre/post (Class I)
- Contrast volume: minimize; contrast/eGFR ratio target <3.7 (Gurm formula)
- Zero-contrast PCI: for eGFR <15 or ESKD — IVUS-guided, PA pressure wires
- Iso-osmolar (iodixanol) vs low-osmolar: COURT trial 2022 — no significant difference in high-risk CKD

## Radial Access — 2025 Class I
- Radial preferred for ALL ACS PCI (Class I, 2025 guideline): reduces bleeding, vascular complications, mortality
- MATRIX trial: radial reduces net adverse clinical events vs femoral
- Femoral: retained for complex cases (large-bore support devices, TAVI, specific anatomy)

## Radiation Dose Management
- Reference air kerma (Kak) threshold: 5 Gy → potential skin injury; report to patient
- Fluoroscopy time and DAP (dose-area product): track and document
- Scatter reduction: collimation, steep angulations minimized, table height, roadmapping

Format with ## headers, bullets, trial names, Class/Level of Evidence.`
  },

  // ── 3. Bleeding ──────────────────────────────────────────────────────────────
  {
    id: "bleeding",
    label: "Bleeding",
    icon: "🩸",
    accent: "var(--red)",
    accentHex: "#c0392b",
    prompt: `You are a board-certified interventional cardiologist. Provide a concise, structured, HIPAA-safe reference on Bleeding Complications Post-PCI per the 2025 ACC/AHA ACS Guideline and ARC-HBR consensus.

## Bleeding Risk Stratification
- **ARC-HBR Criteria** (2023 update): Major criteria (OAC use, CrCl<30, recent ICH, thrombocytopenia <100k, active malignancy, recent major surgery, severe anemia) vs Minor criteria (age ≥75, CrCl 30–59, hemoglobin 11–12.9 g/dL, DM, prior ischemic stroke, NSAIDs)
- 1 major OR 2 minor criteria = High Bleeding Risk
- **PRECISE-DAPT**: ≥25 = HBR; use to guide DAPT duration
- **CRUSADE**: in-hospital NSTEMI bleeding prediction

## Bleeding Classification Systems
- **BARC Types**: 0 (no bleeding) → 5 (fatal); BARC 3a/3b/3c = actionable; BARC 3c/5 = life-threatening
- **TIMI**: Major (ICH or >5g/dL Hgb drop or hemodynamic compromise); Minor; Minimal
- **GUSTO**: Severe/life-threatening; Moderate; Mild

## Access Site Complications
- Radial: <1% major bleeding (vs 3–4% femoral); preferred per 2025 guideline
- Femoral hematoma: EASY grading I–V; Grade III/IV: manual compression, figure-of-8 suture; Grade V: retroperitoneal bleed
- Retroperitoneal hematoma: flank/back pain + hemodynamic instability + falling Hct → urgent CT angiography → IR intervention or surgery
- Pseudoaneurysm: duplex Dx; thrombin injection vs ultrasound-guided compression vs surgery
- Radial artery occlusion: prevention with adequate heparinization; patent hemostasis technique

## Anticoagulation Strategy — 2025 Updates
- UFH: standard; weight-based; ACT-guided (250–300s; 200–250s with GPI)
- Bivalirudin: Class IIb (downgraded from IIa in 2025 ACS guideline) — "alternative to UFH to reduce bleeding in NSTE-ACS"
- Fondaparinux: **Class III (Harm) in PCI** — guide catheter thrombosis risk (2025 guideline)
- Enoxaparin: do not switch between LMWH and UFH during procedure

## GI Bleeding — Prevention and Management
- PPI co-prescription with DAPT: **Class I** (2025 ACS guideline) — especially if prior GI bleed, age >65, NSAID/steroid use
- Preferred PPI: pantoprazole or rabeprazole (less CYP2C19 interference with clopidogrel)
- H. pylori testing: recommended before DAPT initiation in high-risk patients
- Active GI bleed on DAPT: hold P2Y12 temporarily; maintain aspirin if possible; early GI endoscopy

## Intracranial Hemorrhage on DAPT
- Incidence: 0.1–0.3%/year with DAPT; higher with ticagrelor than clopidogrel
- Hold all antiplatelets acutely; neurosurgery/neurology consultation
- Restart DAPT: individualized 4–8 weeks post-ICH (ischemic risk vs re-bleeding)
- Aspirin may be restarted earlier than P2Y12

## Transfusion Thresholds — MINT Trial Update
- MINT trial (2023): liberal strategy (Hgb 10 g/dL) vs restrictive (Hgb 8 g/dL) in ACS — liberal strategy potentially harmful (increase in renal failure, pulmonary edema); signal toward harm
- **2025 ACS guideline**: restrictive transfusion (Hgb <8 g/dL threshold) in hemodynamically stable patients (Class I)
- Transfusion itself associated with increased MACE; minimize if possible

## Ticagrelor Monotherapy — New Class I for Bleeding Reduction
- **Class I (2025 guideline)**: transition to ticagrelor monotherapy ≥1 month post-PCI in patients who tolerated DAPT → reduces BARC 2/3/5 bleeding by ~44%
- Based on TWILIGHT, TICO, GLOBAL LEADERS trials

Format with ## headers, bullets. Cite Class/Level of Evidence.`
  },

  // ── 4. DAPT ──────────────────────────────────────────────────────────────────
  {
    id: "dapt",
    label: "DAPT",
    icon: "💊",
    accent: "var(--blue)",
    accentHex: "#3a8fd4",
    prompt: `You are a board-certified interventional cardiologist. Provide a structured, HIPAA-safe reference on DAPT Duration Post-PCI fully updated to the 2025 ACC/AHA/ACEP/NAEMSP/SCAI ACS Guideline (published February 27, 2025).

## 2025 Major DAPT Changes (vs Prior Guidelines)
- **NEW Class I**: Ticagrelor monotherapy after ≥1 month DAPT post-PCI (Level A) — TWILIGHT, TICO, GLOBAL LEADERS
- Ticagrelor/prasugrel preferred over clopidogrel (Class I) — clopidogrel for intolerance/unavailability only
- Default: 12-month DAPT for low bleeding risk ACS (Class I)
- Replaces 2016 Focused Update on DAPT Duration

## P2Y12 Agent Selection Hierarchy
- **Ticagrelor 90mg BID**: preferred for most ACS (Class I); equal to prasugrel per ACC/AHA 2025
- **Prasugrel 10mg daily**: avoid in prior stroke/TIA (Class III), consider 5mg if age ≥75 or wt <60kg
- **Clopidogrel 75mg**: STEMI + fibrinolysis (Class I); reserve for intolerance/unavailability in PCI
- ACC/AHA 2025 gives ticagrelor and prasugrel equal Class I (differs from ESC 2023 favoring prasugrel)

## DAPT Duration Framework

### Short DAPT ≤3 months (ARC-HBR patients)
- 1 month DAPT → ticagrelor monotherapy: **Class I** (2025 guideline)
- MASTER-DAPT: 1-month DAPT non-inferior vs 12-month in HBR with biodegradable polymer DES
- STOPDAPT-2 ACS: 1-month → clopidogrel monotherapy
- SHORT-DAPT: 3-month DAPT with aspirin cessation
- Eligibility: ≥1 major ARC-HBR criterion or ≥2 minor criteria

### Standard DAPT 12 months (low bleeding risk, ACS)
- Class I per 2025 ACS guideline
- Aspirin 81mg + ticagrelor or prasugrel
- Modern biodegradable polymer DES: lower stent thrombosis than 1st-gen DES

### Extended DAPT >12 months (high ischemic risk, low bleed risk)
- **PEGASUS-TIMI 54**: ticagrelor 60mg BID x 3 years post-MI → 15% MACE reduction; ↑ BARC 3 bleeding
- **DAPT Trial**: 30-month DAPT → ↓ stent thrombosis/MI; ↑ GUSTO moderate/severe bleeding
- **DAPT Score** (Yeh et al.) — use to guide extension:
  - Score ≥2: extended DAPT favored (ischemic benefit > bleeding risk)
  - Score 0–1: standard duration; do not extend
  - Variables: age, smoking, DM, prior MI/PCI, CHF/EF<30%, vein graft stent, stent diameter <3mm, paclitaxel stent

## Aspirin-Free / P2Y12 Monotherapy Strategies
- **TWILIGHT**: ticagrelor monotherapy after 3-month DAPT in high-risk PCI → 44% ↓ BARC 2/3/5 bleeding; non-inferior MACE
- **TICO**: early switch to ticagrelor monotherapy post-ACS — confirmed
- **2025 guideline**: 1-month switch now Class I (upgraded from IIb)

## OAC + Antiplatelet (AF or VTE + ACS/PCI)
- Triple therapy (aspirin + P2Y12 + OAC): limit to 1–4 weeks max (Class I, 2025)
- Then: OAC + clopidogrel (preferred) for up to 12 months (Class I)
- AUGUSTUS, ENTRUST-AF-PCI, PIONEER AF-PCI: support early aspirin discontinuation
- DOAC (rivaroxaban, apixaban) preferred over VKA in AF + PCI

## De-escalation Strategies
- **TROPICAL-ACS**: prasugrel → clopidogrel guided by platelet function test at 14 days — non-inferior
- **HOST-REDUCE-POLYTECH**: prasugrel 10 → 5mg at 1 month; ↓ bleeding, non-inferior ischemic outcomes
- Class IIb per 2025 guideline for unguided de-escalation; guided may be preferred

## CYP2C19 Pharmacogenomics
- Loss-of-function alleles (*2, *3): ↓ clopidogrel efficacy → use ticagrelor or prasugrel
- **TAILOR-PCI**: genotype-guided therapy (ticagrelor in CYP2C19 poor metabolizers) — reduced MACE
- PPI interactions: omeprazole/esomeprazole reduce clopidogrel via CYP2C19; use pantoprazole/rabeprazole

## Perioperative Management
- Elective surgery: delay ≥6 months post-DES when possible (1 month minimum for newer-gen DES)
- Continue aspirin perioperatively (most cases) — stop P2Y12
- Emergency surgery: bridge with cangrelor (IV P2Y12 inhibitor, short half-life — 5–10 min) if thrombosis risk high

Format with ## and ### headers. Cite trial names, Class/Level of Evidence, and dose-specific details.`
  },

  // ── 5. Lipids ─────────────────────────────────────────────────────────────────
  {
    id: "lipids",
    label: "Lipids",
    icon: "🔬",
    accent: "var(--green)",
    accentHex: "#3aab72",
    prompt: `You are a board-certified interventional and preventive cardiologist. Provide a comprehensive, structured, HIPAA-safe reference on Lipid Management Post-PCI updated to BOTH:
1. 2025 ACC/AHA/ACEP/NAEMSP/SCAI ACS Guideline (February 2025)
2. 2026 ACC/AHA/Multisociety Dyslipidemia Guideline (March 13, 2026 — replaces 2018 guideline)

## 2026 Dyslipidemia Guideline — What's New
- Replaces 2018 ACC/AHA Blood Cholesterol Guideline
- New risk tool: **PREVENT-ASCVD equations** replace Pooled Cohort Equations (PCE overestimated risk ~2x)
  - PREVENT extends to age 30; adds 30-year projections up to age 59
  - New risk thresholds: Low <3%, Borderline 3–5%, Intermediate 5–10%, High >10%
- **CPR Framework**: Calculate (PREVENT) → Personalize (risk enhancers) → Reclassify (CAC scoring)
- Core message: **"Earlier and lower for longer"**
- **Universal Lp(a) screening**: now recommended for ALL adults (Class I, 2026 — major upgrade)
- ApoB testing promoted as complementary to LDL-C

## LDL-C Treatment Goals (2026 Guideline)

### Secondary Prevention (Post-PCI / Clinical ASCVD)
- **Very high-risk ASCVD**: LDL-C **<55 mg/dL** (Class I)
  - Definition: ACS within 12 months; prior MI; prior ischemic stroke; symptomatic PAD; OR ≥1 ASCVD event + high-risk conditions (age >65, prior revascularization, DM, smoking, HF, HTN, or LDL >100 despite max statin+ezetimibe)
- **High-risk ASCVD** (not very high): LDL-C **<70 mg/dL** (Class I)
- Intensification reasonable if LDL 55–69 mg/dL with residual risk (DM, polyvascular, elevated Lp(a)) — 2025 ACS guideline aligns
- "Do not de-escalate LLT even at very low LDL-C" — 2026 explicit statement

### ApoB Targets (2026 New)
- Very high-risk: ApoB **<65 mg/dL**
- High-risk: ApoB **<80 mg/dL**

## High-Intensity Statin Therapy — First Line
- **Class I for all post-ACS/PCI** (2025 ACS + 2026 Dyslipidemia guideline)
  - Atorvastatin 40–80 mg
  - Rosuvastatin 20–40 mg
- In-hospital initiation: start before discharge post-ACS (Class I); do not delay
- "Lower is better; do not de-escalate statin even at low LDL" — 2026 guideline
- Statin myopathy: true myopathy rare (0.1%); myalgia common; trial alternate-day dosing or different statin

## Ezetimibe — Step-Up (Class I)
- **IMPROVE-IT**: ezetimibe + simvastatin post-ACS — 7% RRR for CV death/MI/stroke
- Add if LDL-C ≥70 mg/dL (or ≥55 in very high-risk) on max tolerated statin
- LDL reduction: additional 15–25%
- 2025 ACS guideline: concurrent ezetimibe an option at ACS initiation for highest-risk
- RACING trial: statin+ezetimibe vs high-intensity statin alone — similar LDL, less intolerance

## PCSK9 Inhibitors — High-Impact Therapy
- **Evolocumab** (Repatha): FOURIER — 59% LDL↓, 15% MACE RRR; 140mg Q2W or 420mg monthly SC
- **Alirocumab** (Praluent): ODYSSEY OUTCOMES post-ACS — 54% LDL↓, 15% MACE RRR; mortality benefit in LDL >100
- 2026 Indications (Class I):
  - Very high-risk ASCVD not at LDL goal on max statin + ezetimibe
  - Heterozygous FH + ASCVD or multiple risk factors
- **Inclisiran** (Leqvio): siRNA; 50% LDL↓; SC q6 months (day 1, 3 months, then q6 months); ORION-10/11; Class IIa (2026)
- Insurance/PA: often requires documented statin + ezetimibe failure or intolerance

## Bempedoic Acid
- **CLEAR Outcomes (2023)**: 13% MACE RRR in statin-intolerant patients; LDL↓ 21%
- ATP-citrate lyase inhibitor; not activated in muscle → fewer myalgias
- Class IIa (2026) in statin-intolerant patients
- Caution: raises uric acid (avoid in gout); tendon rupture signal; drug interaction with simvastatin (limit to 20mg)

## Triglyceride Management
- **Icosapent ethyl (Vascepa)**: REDUCE-IT — 25% MACE RRR in statin-treated patients, TG 135–499, elevated CV risk — **Class I (2026)**
- Omega-3 carboxylic acids (Epanova): STRENGTH trial — neutral (no benefit)
- Fenofibrate: FIELD, ACCORD — no MACE benefit; use for TG ≥500 (pancreatitis prevention)
- Pemafibrate: PROMINENT — neutral; retired as CV prevention
- TG targets: <150 mg/dL desirable; treat at ≥200 with risk factors; urgent at ≥500

## Lipoprotein(a) — 2026 Major Change
- **Universal Lp(a) screening for all adults: Class I (2026)** — first time in ACC/AHA guideline
- Lp(a) >50 mg/dL (>125 nmol/L): independent ASCVD risk; reclassify risk upward; may justify PCSK9i
- Genetics: ~90% heritable; minimally modifiable by lifestyle
- PCSK9i reduce Lp(a) by 25–30% (secondary benefit)
- Investigational Phase 3: **pelacarsen** (antisense; >80% Lp(a)↓; Lp(a)HORIZON trial), **olpasiran** (siRNA), **muvalaplin** (small molecule oral)
- No FDA-approved Lp(a)-specific agent yet; watch for regulatory approvals 2025–2026

## Post-PCI Lipid Monitoring Protocol
- Fasting lipid panel: 4–8 weeks after initiation or dose adjustment (Class I per 2025 ACS + 2026 guideline)
- Reassess at each cardiology follow-up
- Escalation pathway: High-intensity statin → add ezetimibe → add PCSK9i/inclisiran
- Check LFTs if symptomatic hepatotoxicity suspected (routine LFT monitoring not required)

## Special Populations (2026)
- CKD + ASCVD: LDL goal <55 mg/dL
- Diabetes + ASCVD: LDL <55–70 based on additional risk factors
- HIV: rosuvastatin or pravastatin preferred (protease inhibitor interactions)
- Age >75: continue established LLT; de novo statin via shared decision
- Cancer survivors (≥2-yr life expectancy): continue LLT

Format with ## and ### headers. Cite trials, publication year, Class/Level of Evidence. Flag 2026 NEW recommendations clearly.`
  },

  // ── 6. Cardiac Rehab ─────────────────────────────────────────────────────────
  {
    id: "rehab",
    label: "Cardiac Rehab",
    icon: "🫀",
    accent: "var(--purple)",
    accentHex: "#9b72d4",
    prompt: `You are a board-certified interventional cardiologist and cardiac rehab specialist. Provide a comprehensive, structured, HIPAA-safe reference on Post-PCI Cardiac Rehabilitation per the 2025 ACC/AHA ACS Guideline and current CR evidence base.

## Guideline Recommendation — Class I
- CR referral after ACS/PCI: **Class I** — 2025 ACC/AHA ACS Guideline (confirmed)
- Mortality benefit: 26% reduction all-cause mortality; 31% cardiac mortality (Cochrane meta-analysis 2016, updated 2021)
- 25% reduction in hospital readmissions
- CMS covers: 36 outpatient sessions post-MI, PCI, CABG, stable angina, valve surgery, HFrEF

## Automatic Referral — Closing the 70% Gap
- Only 20–30% eligible patients attend CR nationally (major implementation failure)
- Automatic/opt-out referral models: 3–4x improvement in attendance
- Inpatient CR liaison: pre-discharge referral before patient leaves hospital
- Disparities: women, age >75, racial/ethnic minorities, rural, lower socioeconomic status — actively under-referred
- 2025 ACS guideline: explicitly states home-based CR as an option for those unable/unwilling to attend in-person

## Phase I — Inpatient (Days 1–4)
- Early mobilization within 24h of hemodynamic stability (Class I)
- Ambulation goals: 200–400 feet TID by discharge
- Patient education: medications, diet, activity restrictions, risk factors, warning signs
- Contraindications: HR >120, BP >180/110 at rest, new arrhythmia, decompensated HF, severe aortic stenosis

## Phase II — Outpatient CR (12 Weeks)
- 36 sessions over 12 weeks (CMS standard); 3x/week
- Entry: 1–2 weeks post-uncomplicated PCI; 3–6 weeks post-complicated STEMI

### FITT Exercise Prescription
- **Frequency**: 3–5 sessions/week
- **Intensity**: 50–85% Heart Rate Reserve (Karvonen); RPE 11–14 (Borg 6–20 scale)
  - Karvonen formula: Target HR = [(HRmax − HRrest) × %] + HRrest
  - Alternative: 60–80% peak HR from exercise stress test
- **Type**: Aerobic (treadmill, bike, rowing) + resistance training (begin at 2–4 weeks)
- **Time**: Start 15–20 min, progress to 30–60 min/session

### ECG Monitoring
- High-risk patients: ECG monitoring every session
- Intermediate: first 12 sessions
- Low-risk: first 6 sessions; then BP/symptom monitoring only

### Outcome Measures
- 6-Minute Walk Test (6MWT): baseline and 6/12-week reassessment
- Duke Activity Status Index (DASI)
- Peak VO2 (if available from cardiopulmonary exercise testing)

## Phase III — Maintenance (Long-Term)
- Community gym, YMCA, structured home program
- HBCR: 40–50% of mortality benefit vs center-based; ideal for low-moderate risk
- Telehealth/hybrid CR: pandemic evidence supports equivalence in appropriate patients
- Digital CR apps: FDA-cleared; remote HR monitoring, adherence tracking

## Secondary Prevention Bundle

### Smoking Cessation
- Varenicline (Chantix): most effective (RR 2.3 for abstinence); cardiac safety confirmed in EAGLES trial
- Combination NRT (patch + lozenge): effective OTC
- Bupropion: second-line; caution with seizure risk
- 50% reduction in re-MI risk within 1 year of cessation

### Diet
- Mediterranean diet: PREDIMED — 30% MACE reduction (Class I, 2025 ACS guideline)
- Targets: saturated fat <7% calories, sodium <2g/day, increase omega-3 fish
- Dietitian referral at CR entry

### Psychosocial Intervention
- Depression screening: **PHQ-9** at each CR visit; cutoff ≥10 → refer
- Depression post-ACS: 15–25% prevalence; doubles MACE risk if untreated
- Preferred SSRIs: sertraline, escitalopram (SADHART, ENRICHD trials)
- Anxiety/PTSD: GAD-7 screen; behavioral health referral

### Other Secondary Prevention
- Sexual activity: safe to resume 1–2 weeks post-uncomplicated PCI (≥2 METs equivalent)
- PDE5 inhibitors: **contraindicated with any nitrates** (absolute contraindication)
- Driving: 1 week post-radial PCI; longer if STEMI/HF/arrhythmia
- Return to work: 1–2 weeks (sedentary); 4–6 weeks (physical labor) post-uncomplicated PCI
- Flu/pneumococcal vaccines: Class I for all CAD patients
- Colchicine: Class IIb post-ACS (ACC/AHA 2025); COLCOT trial reduced MACE by 23% at 22.6 months

## Special Populations
- HFrEF post-PCI: HF-ACTION trial — aerobic exercise safe, improves outcomes; start at 40–50% HRR
- Age >75: modified FITT (lower intensity start, balance training, chair-based); equivalent benefit
- Women: equivalent benefit to men; more barriers to attendance; sex-specific protocols advised
- Diabetes: pre/post-exercise glucose monitoring; adjust insulin; avoid hypoglycemia

Format with ## and ### headers. Include specific targets and numbers. Cite trials and Class/Level of Evidence.`
  },

  // ── 7. Secondary Prevention ──────────────────────────────────────────────────
  {
    id: "secondary",
    label: "Secondary Prevention",
    icon: "🛡️",
    accent: "var(--gold)",
    accentHex: "#d4a855",
    prompt: `You are a board-certified interventional cardiologist. Provide a comprehensive, structured, HIPAA-safe reference on Secondary Prevention After PCI/ACS incorporating the 2025 ACC/AHA ACS Guideline, 2026 ACC/AHA Dyslipidemia Guideline, and relevant subspecialty guidelines.

## Beta-Blockers Post-ACS
- Initiation within 24h: **Class I** for STEMI without contraindications (reduces reinfarction, VF risk)
- Oral beta-blocker preferred; IV if hypertension/tachycardia without HF/shock
- Contraindications (acute): decompensated HF, HR <50, PR >0.24s, 2nd/3rd degree AV block, bronchospasm
- Duration post-ACS with normal EF: SMART-DECISION trial (2026, ACC.26) — discontinuation safe at 1 year post-MI in stable patients without HF (new practice-changing data)
- LVEF ≤40%: beta-blocker indefinitely (Class I, mortality benefit; MERIT-HF, CAPRICORN)
- Preferred agents: metoprolol succinate, carvedilol, bisoprolol

## ACE Inhibitors / ARBs Post-ACS
- **Class I** for all post-ACS patients (particularly LVEF ≤40%, DM, hypertension, CKD)
- SAVE, TRACE, AIRE trials: mortality reduction post-MI
- ARB (valsartan, losartan): equivalent efficacy; use if ACEI-intolerant (cough)
- Sacubitril/valsartan (ARNI): Class I for HFrEF ≤40% if stable (PARADIGM-HF; superior to enalapril)
- Initiate within 24h if hemodynamically stable (SBP >100, no cardiogenic shock)

## Aldosterone Antagonists Post-ACS
- **Class I**: eplerenone post-MI with LVEF ≤40% + HF symptoms or DM (EPHESUS trial: 15% mortality ↓)
- Avoid if K >5.0 mEq/L or eGFR <30
- Spironolactone: alternative; more anti-androgenic effects

## SGLT2 Inhibitors — Emerging Role Post-MI
- Empagliflozin, dapagliflozin: Class I for HFrEF regardless of diabetes (EMPEROR-Reduced, DAPA-HF)
- Post-MI with HF: EMPACT-MI trial (empagliflozin post-MI): reduced HF hospitalization (2024 data)
- Benefit: diuresis, BP reduction, renal protection, reverse cardiac remodeling
- Initiate during hospitalization if stable and tolerated

## Aspirin — Long-Term
- Low-dose aspirin 81mg: indefinitely post-ACS (Class I)
- Higher doses (>100mg): no additional benefit; increased bleeding
- Aspirin discontinuation in aspirin-free strategies: only after completing DAPT minimum duration

## Blood Pressure Management
- Target: <130/80 mmHg post-ACS (2017 ACC/AHA HTN Guideline)
- Priority medications post-ACS: beta-blocker + ACEI/ARB
- Add CCB (amlodipine) or thiazide if additional control needed
- Avoid verapamil/diltiazem if EF reduced or with beta-blocker

## Diabetes Management Post-ACS
- Individualized glycemic targets; avoid hypoglycemia (hypoglycemia independently increases MACE)
- SGLT2i (empagliflozin, dapagliflozin): preferred add-on therapy (CV outcome benefit)
- GLP-1 RA (semaglutide, liraglutide): CV benefit in high-risk DM; LEADER, SUSTAIN-6
- SGLT2i and GLP-1 RA: Class I/IIa for patients with established CV disease + T2DM
- Metformin: first-line if tolerated; neutral CV outcomes

## Colchicine — Anti-Inflammatory
- **COLCOT trial**: colchicine 0.5mg daily post-MI → 23% RRR for CV death/cardiac arrest/MI/stroke/urgent revascularization at 22.6 months
- **LoDoCo2**: colchicine in chronic CAD → 31% ↓ CV events
- 2025 ACS guideline: **Class IIb** (reasonable) — consider for post-MI secondary prevention
- Side effects: GI (diarrhea, nausea) — take with food; interaction with CYP3A4

## Omega-3 Fatty Acids
- Icosapent ethyl (VASCEPA) 4g/day: REDUCE-IT — 25% ↓ MACE in statin-treated patients with TG 135–499 (Class I per 2026 Dyslipidemia guideline)
- Regular omega-3 (fish oil, EPA+DHA): ASCEND, ORIGIN — no significant MACE benefit
- Prescribe icosapent ethyl specifically, not generic omega-3

## Vaccination
- Annual influenza: **Class I** (reduces CV events and mortality post-ACS — FLUVACS, IAMI trial)
- Pneumococcal: PPSV23 + PCV15/20 per age/indication
- COVID-19: updated booster per CDC guidance for high-risk CV patients

## Follow-Up Schedule Post-PCI
- 2–4 weeks: wound check, medication reconciliation, CR enrollment, lipid panel
- 6–8 weeks: reassess symptoms, BP, lipids, glucose, LVEF if concerned
- 4–6 months: stress test if recurrent symptoms or high-risk anatomy
- Annual: cardiology follow-up; lipid panel; HbA1c if DM; evaluate medication adherence
- Fasting lipid panel: 4–8 weeks after LLT initiation or dose change (Class I)

## Guideline Reference Library (Applicable)
- 2025 ACC/AHA/ACEP/NAEMSP/SCAI ACS Guideline (JACC/Circulation, Feb 2025)
- 2026 ACC/AHA/Multisociety Dyslipidemia Guideline (JACC/Circulation, Mar 2026)
- 2021 ACC/AHA/SCAI Coronary Revascularization Guideline (Circulation, Dec 2021)
- 2022 ACC/AHA Chest Pain Guideline
- 2022 AHA/ACC/HFSA HF Guideline
- 2017 ACC/AHA HTN Guideline
- ARC-HBR Consensus 2020/2023
- 2021 ACC/AHA Cardiogenic Shock Scientific Statement

Format with ## headers and bullets. Cite trial names, Class/Level of Evidence, doses. Highlight 2025/2026 updates.`
  },

  // ── 8. CIN / CA-AKI ─────────────────────────────────────────────────────────
  {
    id: "cin",
    label: "CIN / CA-AKI",
    icon: "🫘",
    accent: "var(--blue)",
    accentHex: "#2e8bbf",
    prompt: `You are a board-certified interventional cardiologist with expertise in renal protection during cardiac procedures. Provide a comprehensive, structured, HIPAA-safe clinical reference on Contrast-Induced Nephropathy (CIN) / Contrast-Associated Acute Kidney Injury (CA-AKI) covering full pre-procedural risk stratification, peri-procedural prevention, and post-procedural management. Use the most current evidence through 2025.

## Terminology & Definition
- Preferred modern term: **Contrast-Associated AKI (CA-AKI)** or **Contrast-Induced AKI (CI-AKI)**
- "CIN" being phased out but still widely used clinically
- **KDIGO definition**: rise in serum creatinine ≥0.3 mg/dL within 48h OR ≥1.5× baseline within 7 days after contrast administration
- Older "CIN" definition: sCr rise >0.5 mg/dL or >25% from baseline within 72h
- Important caveat: recent data (propensity-matched studies) suggest CA-AKI incidence may be overestimated; spontaneous AKI in sick hospitalized patients confounds attribution

## Incidence & Prognosis
- General PCI population: ~2% incidence
- High-risk patients (CKD + DM): up to 30–50%
- STEMI/primary PCI: 13–19% CA-AKI rate
- TAVR: 10–30% AKI rate
- CA-AKI requiring dialysis: <1% general; 3.1% with baseline CKD; up to 12% with DM + severe CKD
- 18% requiring dialysis: permanent dialysis dependence
- Prognosis: CA-AKI independently associated with long-term mortality (HR 2.26 in CKD; HR 2.62 in severe CKD — Rihal et al.); 35.7% in-hospital mortality in dialysis cohort

## PRE-PROCEDURAL RISK STRATIFICATION

### Mehran Risk Score (Most Validated)
Eight variables: hypotension, IABP use, CHF, age >75, anemia, DM, contrast volume, eGFR
- Score 0–5: Low risk (7.5% CA-AKI; 0.04% dialysis)
- Score 6–10: Moderate risk (14% CA-AKI; 0.12% dialysis)
- Score 11–15: High risk (26% CA-AKI; 1.09% dialysis)
- Score ≥16: Very high risk (57% CA-AKI; 12.6% dialysis)

### NCDR CathPCI CA-AKI Risk Model
- Variables: eGFR, DM, contrast volume, STEMI, CHF, cardiogenic shock, age, female sex
- Available at ACC.org; validated in large registry cohort
- More contemporary than Mehran (developed from NCDR database)

### Contrast Volume to eGFR Ratio (CMV/CrCl or CMV/eGFR)
- CMV/CrCl ratio: validated independent predictor of CA-AKI in primary PCI setting
- **Cut-off ≥3.7** (Laskey et al.): significantly increased CA-AKI and dialysis risk
- **Cut-off ≥2.5** (Gurm et al.): increased risk threshold; strong signal at ratio ≥3
- Practical target: aim for CMV/eGFR **<3.7** in all high-risk cases
- Zero-contrast PCI: consider for eGFR <15 or ESKD patients

### High-Risk Patient Identification
- **CKD** (eGFR <60): most important single risk factor; risk rises steeply below eGFR 30
- **Diabetes mellitus**: independent risk factor (hyperglycemia → ROS → renal vasoconstriction)
- **Age >75**: reduced renal reserve
- **Hemodynamic instability / cardiogenic shock**: renal hypoperfusion compounds contrast toxicity
- **Anemia** (Hct <39% men, <36% women): Mehran score variable; independent predictor
- **CHF / reduced EF** (EF <40%): impaired renal perfusion; reduced hydration tolerance
- **Volume depletion**: dehydration, aggressive diuresis pre-procedure
- **Concurrent nephrotoxins**: NSAIDs, aminoglycosides, cyclosporine, tacrolimus, IV vancomycin
- **Multiple procedures within 72 hours**: contrast load accumulation; delay staged procedures if eGFR at risk

### Baseline Labs Required
- Serum creatinine + eGFR (CKD-EPI equation): within 48–72h pre-procedure when possible
- In emergency STEMI: proceed without delay; document pre-procedure labs retrospectively
- BUN, electrolytes, urinalysis (assess proteinuria → CKD staging)

## PRE-PROCEDURAL PREVENTION

### IV Hydration — Cornerstone (Class I, ACC/AHA)
- **Isotonic saline (0.9% NaCl)**: superior to hypotonic (0.45%) saline — Mueller trial (0.7% vs 2.0% CA-AKI)
- Standard protocol: **1 mL/kg/hr for 12h pre-procedure; continue 12–24h post-procedure** (Class I, Level B)
- Reduced rate for HF/EF ≤35%: **0.5 mL/kg/hr** to avoid pulmonary edema
- POSEIDON trial: **LVEDP-guided** hydration superior to standard protocol (3.4% vs 6.7% CA-AKI) — use 3 mL/kg/hr if LVEDP <13; 1.5 mL/kg/hr if LVEDP 13–18; 1 mL/kg/hr if LVEDP >18
- RenalGuard system: matched urine output with IV saline at high rates (MYTHOS, REMEDIAL II); reduces CA-AKI in very high-risk patients; 2025 meta-analysis confirms benefit in CKD eGFR 20–60
- Sodium bicarbonate (1.26%): PRESERVE trial (2018, NEJM) — **no benefit** over isotonic saline; not recommended routinely

### N-Acetylcysteine (NAC) — Not Recommended
- PRESERVE trial (2018): NAC 1200mg BID x 4 doses — **no benefit** vs placebo for CA-AKI prevention
- Meta-analyses conflicting; creatinine-lowering effect may be pharmacologic artifact (NAC reduces creatinine independently of renal function)
- Current recommendation: **do not routinely use** (Class IIb at best; many guidelines now Class III)

### Statins — Consider if Not Already Prescribed
- PRATO-ACS trial: high-dose rosuvastatin 40mg loading → 20mg maintenance significantly reduced CA-AKI in statin-naive NSTEMI (6.7% vs 15.1%)
- ARMYDA-CA-AKI: atorvastatin pretreatment reduced CA-AKI
- Mechanism: anti-inflammatory, antioxidant, endothelial protective effects
- Current practice: virtually all PCI patients already on high-intensity statin (Class I per 2025 ACS guideline); if statin-naive pre-procedure, load with atorvastatin 80mg or rosuvastatin 40mg

### SGLT2 Inhibitors — Emerging Data (2023–2025)
- Observational and small RCT data: empagliflozin and dapagliflozin may reduce CA-AKI in diabetics undergoing PCI
- Mechanism: SGLT2i improve renal hemodynamics, reduce tubular oxygen demand, anti-inflammatory
- SGLT2i and contrast: historical concern about euDKA peri-procedure — hold 24–48h before elective procedures (ADA/ACC guidance)
- Emerging data suggests benefit without harm in acute procedures; ongoing RCTs
- Current recommendation: individualized; consider continuing for established HF/CKD indication; hold for elective procedures per ADA guidance

### Inorganic Nitrate — Emerging (NITRATE-CIN Trial, 2024)
- **NITRATE-CIN trial** (Eur Heart J, 2024): inorganic nitrate (sodium nitrate) reduced CA-AKI after coronary angiography for ACS
- Mechanism: nitric oxide–mediated renal vasodilation; counteracts contrast-induced vasoconstriction
- Not yet in major guidelines; promising signal; watch for larger trials

### Medications to HOLD Pre-Procedure
- **NSAIDs / COX-2 inhibitors**: hold 24–48h pre; interfere with renal autoregulation
- **Diuretics**: hold morning dose day of procedure in euvolemic patients
- **Metformin**: hold on day of procedure + 48h post if eGFR <60 (lactic acidosis risk, not CA-AKI)
- **ACEI/ARB**: CAPTAIN trial — withholding ≥24h pre-procedure resulted in significant ↓ in post-procedure creatinine rise in moderate CKD (creatinine ≥1.7); KDIGO does not formally recommend holding; individualized decision — consider holding in CKD stage 3b+
- **Nephrotoxic antibiotics** (aminoglycosides, vancomycin): optimize timing around procedure

## PERI-PROCEDURAL PREVENTION

### Contrast Agent Selection
- **Low-osmolar contrast media (LOCM)**: iohexol, iomeprol, iopromide, iopamidol — recommended over high-osmolar (Class I)
- **Iso-osmolar contrast media (IOCM)**: iodixanol (Visipaque) — theoretically least nephrotoxic
  - Meta-analysis: iodixanol vs iohexol specifically — iodixanol significantly less CA-AKI (OR 0.25)
  - vs other LOCM: no consistent advantage (OR 0.77, NS in large meta-analysis)
  - COURT trial (2022): no significant difference between iodixanol and low-osmolar in high-risk CKD
  - Practical: avoid iohexol in high-risk CKD; iodixanol or iopamidol reasonable first choices
- **Avoid ionic high-osmolar contrast** (diatrizoate): obsolete; significantly more nephrotoxic

### Contrast Volume Minimization — Critical
- Target **CMV/eGFR ratio <3.7** (Laskey formula); aim for <2.5 in very high-risk
- Contrast-saving techniques:
  - Roadmapping and digital subtraction
  - Biplane angiography
  - Co-registration (angiography + IVUS/OCT)
  - Pressure wire physiology (FFR/iFR) instead of multiple angiographic views
  - **Ultra-low contrast PCI**: IVUS-guided stenting with minimal contrast; <20 mL total
  - Diluted contrast (50:50 with saline): reduces osmotic load; some evidence supports
- Split procedures: for complex multivessel disease, stage procedures ≥72h apart if eGFR at risk

### Hemodynamic Optimization
- Avoid prolonged hypotension; maintain MAP >65 mmHg during procedure
- Cardiogenic shock: consider hemodynamic support (Impella/IABP) to improve renal perfusion BEFORE contrast administration when feasible
- Optimize fluid status: avoid over-diuresis pre-procedure

### IVUS-Guided Zero-Contrast PCI
- Validated technique for eGFR <15 or ESKD on dialysis
- IVUS for vessel sizing, lesion assessment, stent optimization
- Angiography replaced by IVUS; contrast used only for guide placement
- Case series and registries: excellent outcomes with near-zero contrast volumes (Briguori et al., 2024)
- Outcomes: ultra-low contrast PCI (<20 mL) — similar MACE, avoided dialysis initiation (JACC 2024)

## POST-PROCEDURAL MONITORING & MANAGEMENT

### Creatinine Monitoring
- **Mandatory in high-risk patients** (eGFR <60, DM, contrast volume >100 mL):
  - Serum creatinine at 24h and 48–72h post-procedure
  - Peak creatinine rise typically at 48–72h; return toward baseline by 7–10 days
- Low-risk patients: discharge with instructions to report oliguria, edema, fatigue

### Post-Procedure Hydration
- Continue IV isotonic saline at 1 mL/kg/hr for 12–24h post-procedure in high-risk
- Oral hydration: encourage liberal fluid intake if euvolemic and no HF
- Monitor urine output: target >0.5–1 mL/kg/hr

### Diagnosis of CA-AKI
- CA-AKI confirmed: sCr rise ≥0.3 mg/dL within 48h or ≥1.5× baseline within 7 days
- Rule out alternative causes: atheroembolic disease (eosinophilia, livedo reticularis, blue toe syndrome — more common with aortic manipulation), sepsis, volume depletion, nephrotoxins
- Urinalysis/urine microscopy: granular casts → tubular injury; white cell casts → infection
- Renal ultrasound: if prolonged or unexplained AKI

### Management of Established CA-AKI
- **Hydration**: maintain euvolemia; avoid further nephrotoxin exposure
- **Hold ACEi/ARB** until renal function recovers
- **Hold metformin** until sCr returns to baseline
- **Nephrology consultation**: if sCr rise >1.0 mg/dL, oliguria, or signs of uremia
- **Dialysis indications**: hyperkalemia (K >6.5), severe acidosis, pulmonary edema refractory to diuretics, symptomatic uremia
- Most CA-AKI is non-oliguric and self-limited; recovery within 7–14 days typical

### Long-Term Renal Follow-Up
- Repeat eGFR and creatinine at 30-day follow-up
- If eGFR does not return to baseline: nephrology referral for CKD staging and management
- Cardiovascular risk of CKD: ASCVD risk markedly elevated in CKD; reinforce statin + RAAS therapy
- SGLT2i: initiate/continue for CKD + T2DM (CREDENCE, DAPA-CKD) — renal protective

## SPECIAL SITUATIONS

### Dialysis Patients (ESKD)
- No meaningful residual renal function to protect in most ESKD
- Risk: volume overload, contrast osmotic effect
- Strategy: minimize contrast volume; IVUS-guided zero-contrast PCI preferred
- Schedule dialysis post-procedure if large volumes used (>100 mL) to remove osmotic load; not routinely needed for small volumes

### STEMI / Emergency PCI
- Do not delay primary PCI for hydration — door-to-balloon time prioritized (Class I)
- Document baseline creatinine if available; obtain stat if not
- Start IV saline as soon as possible during/post-procedure
- Accept higher CA-AKI risk in exchange for timely reperfusion

### CKD Stage 3b–5 (eGFR 15–44) — High Risk Protocol
- Pre-hydrate 12h isotonic saline at 1 mL/kg/hr (0.5 mL/kg/hr if EF ≤35%)
- Use LVEDP-guided hydration if available (POSEIDON protocol)
- Target contrast volume <30 mL if possible; absolute maximum CMV/eGFR ratio <2.5
- Consider iodixanol (iso-osmolar) over iohexol
- IVUS/OCT guidance to reduce contrast use
- Post-hydrate 12–24h; check creatinine at 24h and 48h
- Nephrology pre-notification

## WHAT DOES NOT WORK (Save Time, Avoid These)
- **Sodium bicarbonate**: PRESERVE trial — no benefit (Class III per most current practice)
- **NAC (N-acetylcysteine)**: PRESERVE trial — no benefit (not routinely recommended)
- **Theophylline**: insufficient evidence; not recommended
- **Fenoldopam**: CONTRAST trial — no benefit vs placebo + saline
- **Dopamine**: no benefit; vasopressor doses harmful
- **Routine forced diuresis with furosemide** (without RenalGuard): worsens CA-AKI

## Quick Reference: CA-AKI Prevention Bundle
Pre-procedure checklist for high-risk patients (eGFR <60 or DM):
1. ✓ Calculate Mehran score and CMV/eGFR target
2. ✓ Start IV isotonic saline 12h pre (1 mL/kg/hr; 0.5 if EF ≤35%)
3. ✓ Hold NSAIDs, diuretics, consider holding ACEI/ARB in CKD 3b+
4. ✓ Confirm statin on board (high-intensity); load if statin-naive
5. ✓ Choose LOCM or iodixanol; avoid iohexol in CKD
6. ✓ Use IVUS/co-registration to minimize contrast volume; target CMV/eGFR <3.7
7. ✓ Continue IV hydration 12–24h post-procedure
8. ✓ Check creatinine at 24h and 48–72h post
9. ✓ Nephrology notification if eGFR <30 or ESKD

Format with ## and ### headers and detailed bullet points. Include specific numbers, thresholds, and trial names. This is critical for high-risk CKD/DM patients undergoing PCI.`
  }
];

// ── Markdown renderer ──────────────────────────────────────────────────────────
function md(text) {
  if (!text) return "";
  return text
    .replace(/^### (.+)$/gm, '<h3>$1</h3>')
    .replace(/^## (.+)$/gm, '<h2>$1</h2>')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.+?)\*/g, '<em>$1</em>')
    .replace(/`(.+?)`/g, '<code>$1</code>')
    .replace(/^- (.+)$/gm, '<li>$1</li>')
    .replace(/(<li>[\s\S]*?<\/li>\n?)+/g, m => `<ul>${m}</ul>`)
    .replace(/\n{2,}/g, '\n')
    .replace(/^(?!<[hul])(.+)$/gm, s => s.trim() ? `<p>${s}</p>` : '');
}

// ── Loading dots ───────────────────────────────────────────────────────────────
function Dots({ color }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 6, padding: "1.8rem 0" }}>
      {[0,1,2].map(i => (
        <span key={i} className="pulse" style={{
          display: "block", width: 9, height: 9, borderRadius: "50%",
          background: color || "var(--gold)", animationDelay: `${i*0.17}s`
        }} />
      ))}
      <span style={{ marginLeft: 8, fontSize: "0.78rem", color: "var(--text3)" }}>
        Loading guideline content…
      </span>
    </div>
  );
}

// ── App ────────────────────────────────────────────────────────────────────────
export default function App() {
  const [activeId, setActiveId] = useState(null);
  const [cache, setCache] = useState({});
  const [loading, setLoading] = useState({});
  const [errors, setErrors] = useState({});
  const [query, setQuery] = useState("");
  const [qResult, setQResult] = useState(null);
  const [qLoading, setQLoading] = useState(false);
  const scrollRef = useRef(null);
  const inputRef = useRef(null);

  const fetchModule = useCallback(async (mod) => {
    setActiveId(mod.id);
    setQResult(null);
    scrollRef.current?.scrollTo({ top: 0, behavior: "smooth" });
    if (cache[mod.id]) return;
    setLoading(p => ({ ...p, [mod.id]: true }));
    setErrors(p => ({ ...p, [mod.id]: null }));
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: MODEL, max_tokens: 1000,
          system: "You are a precise interventional cardiologist. Respond ONLY with structured clinical markdown. No preamble. No disclaimers. Start immediately with content.",
          messages: [{ role: "user", content: mod.prompt }]
        })
      });
      const data = await res.json();
      const text = data.content?.map(b => b.text || "").join("") || "No content returned.";
      setCache(p => ({ ...p, [mod.id]: text }));
    } catch {
      setErrors(p => ({ ...p, [mod.id]: "Connection error. Please try again." }));
    } finally {
      setLoading(p => ({ ...p, [mod.id]: false }));
    }
  }, [cache]);

  const handleQuery = useCallback(async () => {
    if (!query.trim() || qLoading) return;
    setQLoading(true);
    setQResult(null);
    setActiveId(null);
    scrollRef.current?.scrollTo({ top: 0, behavior: "smooth" });
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: MODEL, max_tokens: 1000,
          system: "You are a board-certified interventional cardiologist. Answer concisely with evidence-based clinical information. Use ## markdown headers and bullets. Cite trial names and Class/Level of Evidence (2025 ACC/AHA ACS, 2026 Dyslipidemia, 2021 Revascularization guidelines). No patient data. No preamble.",
          messages: [{ role: "user", content: query }]
        })
      });
      const data = await res.json();
      setQResult(data.content?.map(b => b.text || "").join("") || "No response.");
    } catch {
      setQResult("Query failed. Please check your connection and try again.");
    } finally {
      setQLoading(false);
    }
  }, [query, qLoading]);

  const activeMod = MODULES.find(m => m.id === activeId);

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100dvh", overflow: "hidden", background: "var(--bg)" }}>

      {/* ── HEADER ── */}
      <header style={{
        background: "linear-gradient(180deg, #07111f 0%, var(--bg) 100%)",
        borderBottom: "1px solid var(--border)",
        padding: "clamp(0.65rem, 2vw, 1.1rem) clamp(0.9rem, 3vw, 1.8rem)",
        flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "space-between", gap: "0.8rem", flexWrap: "wrap"
      }}>
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", marginBottom: "0.1rem" }}>
            <span style={{ fontSize: "0.95rem" }}>🩺</span>
            <span style={{ fontSize: "0.6rem", letterSpacing: "0.18em", textTransform: "uppercase", color: "var(--text3)", fontWeight: 500 }}>
              Interventional Cardiology Decision Support
            </span>
          </div>
          <h1 style={{
            fontFamily: "'DM Serif Display', serif",
            fontSize: "clamp(1.5rem, 4.5vw, 2rem)",
            fontWeight: 400, fontStyle: "italic",
            color: "var(--text)", letterSpacing: "-0.01em", lineHeight: 1,
            margin: 0
          }}>
            Stent<span style={{ color: "var(--gold)" }}>Wise</span>
          </h1>
          <p style={{ fontSize: "0.62rem", color: "var(--text3)", marginTop: "0.2rem", letterSpacing: "0.07em" }}>
            2025 ACS · 2026 Lipids · 2021 Revascularization · AUC · AI-Powered
          </p>
        </div>
        <div style={{
          background: "rgba(212,168,85,0.06)", border: "1px solid rgba(212,168,85,0.15)",
          borderRadius: 8, padding: "0.5rem 0.75rem", maxWidth: 310
        }}>
          <p style={{ fontSize: "0.63rem", color: "var(--text3)", lineHeight: 1.55, margin: 0 }}>
            <strong style={{ color: "var(--gold2)" }}>⚕️ HIPAA Notice</strong> — No patient data collected or processed. General clinical reference only.
          </p>
        </div>
      </header>

      {/* ── MODULE NAV ── */}
      <nav style={{
        background: "var(--bg2)", borderBottom: "1px solid var(--border)",
        padding: "0.55rem clamp(0.7rem, 2vw, 1.4rem)",
        display: "flex", gap: "0.4rem", flexWrap: "wrap", flexShrink: 0,
        overflowX: "auto"
      }}>
        {MODULES.map(m => {
          const active = activeId === m.id;
          return (
            <button key={m.id} onClick={() => fetchModule(m)} style={{
              background: active ? `${m.accentHex}18` : "rgba(255,255,255,0.025)",
              border: `1px solid ${active ? m.accentHex + "50" : "var(--border)"}`,
              borderRadius: 7, padding: "0.42rem 0.85rem",
              color: active ? "var(--text)" : "var(--text2)",
              fontSize: "clamp(0.7rem, 1.7vw, 0.79rem)", fontWeight: active ? 500 : 400,
              cursor: "pointer", display: "flex", alignItems: "center", gap: "0.32rem",
              transition: "all 0.15s", whiteSpace: "nowrap", fontFamily: "'DM Sans', sans-serif"
            }}>
              <span>{m.icon}</span>
              <span>{m.label}</span>
              {cache[m.id] && <span className="badge" style={{ background: m.accentHex, opacity: 0.65 }} />}
            </button>
          );
        })}
      </nav>

      {/* ── SEARCH ── */}
      <div style={{
        background: "var(--bg3)", borderBottom: "1px solid var(--border)",
        padding: "0.55rem clamp(0.7rem, 2vw, 1.4rem)",
        display: "flex", gap: "0.45rem", flexShrink: 0
      }}>
        <input
          ref={inputRef}
          value={query}
          onChange={e => setQuery(e.target.value)}
          onKeyDown={e => e.key === "Enter" && handleQuery()}
          placeholder="Ask anything — 'FFR vs iFR', 'TAVI DAPT', 'Lp(a) in high-risk PCI', 'colchicine post-ACS'…"
          style={{
            flex: 1, background: "rgba(255,255,255,0.04)",
            border: "1px solid var(--border2)", borderRadius: 7,
            padding: "0.52rem 0.85rem", color: "var(--text)",
            fontSize: "clamp(0.74rem, 1.9vw, 0.82rem)", outline: "none",
            fontFamily: "'DM Sans', sans-serif"
          }}
        />
        <button onClick={handleQuery} disabled={qLoading || !query.trim()} style={{
          background: qLoading || !query.trim() ? "var(--border2)" : `linear-gradient(135deg, var(--gold), var(--gold2))`,
          border: "none", borderRadius: 7,
          padding: "0.52rem clamp(0.75rem, 2vw, 1.2rem)",
          color: qLoading || !query.trim() ? "var(--text3)" : "var(--bg)",
          fontSize: "0.78rem", fontWeight: 600,
          cursor: qLoading || !query.trim() ? "not-allowed" : "pointer",
          whiteSpace: "nowrap", transition: "all 0.15s", fontFamily: "'DM Sans', sans-serif"
        }}>
          {qLoading ? "…" : "Ask AI"}
        </button>
      </div>

      {/* ── CONTENT ── */}
      <main ref={scrollRef} style={{ flex: 1, overflowY: "auto", padding: "clamp(0.8rem, 2vw, 1.5rem) clamp(0.8rem, 3vw, 1.8rem)" }}>

        {/* Query result */}
        {(qResult || qLoading) && (
          <div className="fadein" style={{
            background: "rgba(212,168,85,0.05)",
            border: "1px solid rgba(212,168,85,0.15)",
            borderRadius: 10, padding: "1rem 1.2rem", marginBottom: "1.4rem"
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", marginBottom: "0.6rem" }}>
              <span style={{ fontSize: "0.6rem", letterSpacing: "0.12em", textTransform: "uppercase", color: "var(--gold2)" }}>AI Clinical Query</span>
              <div style={{ flex: 1, height: 1, background: "rgba(212,168,85,0.1)" }} />
              {!qLoading && (
                <button onClick={() => setQResult(null)} style={{
                  background: "none", border: "none", color: "var(--text3)",
                  cursor: "pointer", fontSize: "1.1rem", lineHeight: 1, padding: "0 0.1rem"
                }}>×</button>
              )}
            </div>
            {qLoading ? <Dots /> : <div className="mdc" dangerouslySetInnerHTML={{ __html: md(qResult) }} />}
          </div>
        )}

        {/* Module content */}
        {activeId && (
          <div className="fadein">
            <div style={{ display: "flex", alignItems: "center", gap: "0.6rem", marginBottom: "1rem" }}>
              <span style={{ fontSize: "1.15rem" }}>{activeMod?.icon}</span>
              <h2 style={{
                fontFamily: "'DM Serif Display', serif",
                fontSize: "clamp(1.05rem, 3vw, 1.35rem)",
                fontWeight: 400, fontStyle: "italic",
                color: activeMod?.accentHex, margin: 0
              }}>{activeMod?.label}</h2>
              <div style={{ flex: 1, height: 1, background: `${activeMod?.accentHex}18` }} />
              <span style={{ fontSize: "0.59rem", color: "var(--text3)", letterSpacing: "0.07em", whiteSpace: "nowrap" }}>
                {activeId === "lipids" ? "2026 ACC/AHA" : activeId === "auc" ? "2021 + 2025 ACC/AHA" : activeId === "cin" ? "KDIGO · SCAI · 2025" : "2025 ACC/AHA"}
              </span>
            </div>

            {loading[activeId] && <Dots color={activeMod?.accentHex} />}

            {errors[activeId] && (
              <div style={{
                background: "rgba(224,82,82,0.07)", border: "1px solid rgba(224,82,82,0.22)",
                borderRadius: 8, padding: "0.85rem 1rem",
                color: "#e07070", fontSize: "0.82rem",
                display: "flex", alignItems: "center", gap: "0.8rem"
              }}>
                <span>{errors[activeId]}</span>
                <button onClick={() => {
                  setCache(p => { const c = { ...p }; delete c[activeId]; return c; });
                  fetchModule(activeMod);
                }} style={{
                  background: "none", border: "1px solid #e07070", borderRadius: 5,
                  color: "#e07070", padding: "0.2rem 0.55rem",
                  cursor: "pointer", fontSize: "0.76rem", whiteSpace: "nowrap"
                }}>Retry</button>
              </div>
            )}

            {cache[activeId] && !loading[activeId] && (
              <div className="mdc" dangerouslySetInnerHTML={{ __html: md(cache[activeId]) }} />
            )}
          </div>
        )}

        {/* Landing */}
        {!activeId && !qResult && !qLoading && (
          <div style={{ textAlign: "center", paddingTop: "clamp(1.5rem, 6vw, 3.5rem)" }}>
            <div style={{ fontFamily: "'DM Serif Display', serif", fontSize: "2.5rem", fontStyle: "italic", color: "var(--border2)", marginBottom: "0.6rem" }}>
              Stent<span style={{ color: "var(--gold2)" }}>Wise</span>
            </div>
            <p style={{ fontSize: "0.82rem", color: "var(--text3)", lineHeight: 1.75, maxWidth: 440, margin: "0 auto 0.6rem" }}>
              Evidence-based decision support for interventional cardiologists.<br />
              Select a module or ask any clinical question above.
            </p>
            <p style={{ fontSize: "0.7rem", color: "var(--border2)", marginBottom: "2.2rem" }}>
              2025 ACC/AHA ACS · 2026 Dyslipidemia · 2021 Revascularization · AUC
            </p>
            <div style={{ display: "flex", gap: "0.65rem", justifyContent: "center", flexWrap: "wrap", maxWidth: 560, margin: "0 auto" }}>
              {MODULES.map(m => (
                <div key={m.id} onClick={() => fetchModule(m)} style={{
                  background: `${m.accentHex}0c`, border: `1px solid ${m.accentHex}25`,
                  borderRadius: 10, padding: "0.85rem 0.95rem",
                  cursor: "pointer", minWidth: 105, textAlign: "center",
                  transition: "all 0.15s"
                }}>
                  <div style={{ fontSize: "1.35rem", marginBottom: "0.35rem" }}>{m.icon}</div>
                  <div style={{ fontSize: "0.68rem", color: "var(--text3)", lineHeight: 1.3 }}>{m.label}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* ── FOOTER ── */}
      <footer style={{
        background: "#040910", borderTop: "1px solid var(--border)",
        padding: "0.42rem clamp(0.7rem, 2vw, 1.4rem)",
        display: "flex", justifyContent: "space-between", gap: "0.4rem",
        flexWrap: "wrap", flexShrink: 0
      }}>
        <span style={{ fontSize: "0.59rem", color: "var(--border2)" }}>StentWise v2 · For licensed healthcare professionals only · Not a substitute for clinical judgment</span>
        <span style={{ fontSize: "0.59rem", color: "var(--border2)" }}>No PHI stored · HIPAA-safe</span>
      </footer>
    </div>
  );
}
